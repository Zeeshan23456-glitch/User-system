# Course Management REST API (Without Database)

Express.js REST API with MVC structure and JWT authentication. MongoDB/Mongoose has been removed. Data is stored in memory only.

## Requirements
- Node.js 18+
- npm
- Postman (optional, for API testing)

## Run on Windows
1. Extract the ZIP and open this folder in VS Code.
2. Open a terminal in the `course-management-api` folder.
3. Install dependencies: `npm install`
4. Check `.env` and set a private, long `JWT_SECRET`.
5. Start development server: `npm run dev` (or `npm start`).
6. Base URL: `http://localhost:5000`

## Important limitation
There is no database. Users, categories, courses and passwords are kept in RAM and are deleted whenever the server stops or restarts. This is suitable for demos/testing only, not production. Register a user and create categories again after every restart.

## Endpoints
### Public authentication
- `POST /api/auth/register` — `{ "name":"Zeeshan", "email":"zeeshan@example.com", "password":"secret123" }`
- `POST /api/auth/login` — `{ "email":"zeeshan@example.com", "password":"secret123" }`

### Protected categories
Use `Authorization: Bearer YOUR_TOKEN` after login.
- `POST /api/categories` — `{ "name":"Programming", "description":"Programming courses" }`
- `GET /api/categories`
- `GET /api/categories/:id`
- `PUT /api/categories/:id` — send `name` and optional `description`
- `DELETE /api/categories/:id`

### Protected courses
- `POST /api/courses` — `{ "title":"Node.js Basics", "description":"Learn Express", "instructor":"Ali", "price":49.99, "category":"CATEGORY_ID_FROM_GET_CATEGORIES" }`
- `GET /api/courses`
- `GET /api/courses/:id`
- `PUT /api/courses/:id` — send `title`, `instructor`, `price`, `category`, and optional `description`
- `DELETE /api/courses/:id`

## Quick test
1. Start server and open `GET http://localhost:5000/`.
2. Register and then log in using the examples above.
3. Copy the login token into the Bearer Token authorization field in Postman.
4. Create a category, then copy its `id` from the response into the course `category` field.
